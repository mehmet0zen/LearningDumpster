using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using Photon.Pun;
using Photon.Realtime;
using UnityEngine.UI;

public class PlayerItem : MonoBehaviourPunCallbacks
{
    public TextMeshProUGUI playerName;
    public RawImage BgImage;
    public Color highlight;
    public GameObject skinChange;

    ExitGames.Client.Photon.Hashtable playerProperties = new ExitGames.Client.Photon.Hashtable();
    public Image playerSkin;
    public Sprite[] skinIcons;
    public GameObject crown;

    Player player;
    PhotonView view;

    public void SetPlayerInfo(Player _player) {
        playerName.text = _player.NickName;
        player = _player;
        if (player.IsMasterClient) {
            crown.SetActive(true);
        } else {
            crown.SetActive(false);
        }
        UpdatePlayerItem(player);
    }

    public void ApplyLocalChanges() {
        Image arrow = skinChange.GetComponent<Image>();
        BgImage.color = highlight;
        arrow.color = highlight;
        skinChange.SetActive(true);
    }

    public void OnClickArrow() {
        if ((int) playerProperties["playerAvatar"] == skinIcons.Length - 1) {
            playerProperties["playerAvatar"] = 0;
        } else {
            playerProperties["playerAvatar"] = (int)playerProperties["playerAvatar"] + 1;
        }
        PhotonNetwork.SetPlayerCustomProperties(playerProperties);
    }

    public override void OnPlayerPropertiesUpdate(Player targetPlayer, ExitGames.Client.Photon.Hashtable changedProps)
    {
        if (player == targetPlayer) {
            UpdatePlayerItem(targetPlayer);
        }
    }

    void UpdatePlayerItem(Player player) {
        if (player.CustomProperties.ContainsKey("playerAvatar")) {
            playerSkin.sprite = skinIcons[(int)player.CustomProperties["playerAvatar"]];
            playerProperties["playerAvatar"] = (int)player.CustomProperties["playerAvatar"];
        } else {
            playerProperties["playerAvatar"] = 0;
        }
    }
}
