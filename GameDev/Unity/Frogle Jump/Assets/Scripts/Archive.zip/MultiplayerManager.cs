using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Photon.Pun;
using Photon.Realtime;
using TMPro;
using UnityEngine.UI;

public class MultiplayerManager : MonoBehaviourPunCallbacks
{
    public GameObject pauseCanvas;
    public GameObject playerFeed;
    public GameObject feedHolder;
    bool paused = false;
    // public PlayerSpawner spawner;
    // CameraControlMultiplayer cameraControl;

    // private void Awake() {
        // cameraControl = FindObjectOfType<CameraControlMultiplayer>();
        // spawner.SpawnPlayers();
    // }

    private void Update() {
        if (Input.GetKeyDown(KeyCode.Escape) || Input.GetKeyDown(KeyCode.P)) {
            if (paused) {
                paused = false;
                pauseCanvas.SetActive(false);
            } else {
                paused = true;
                pauseCanvas.SetActive(true);
            }
        }
    }

    public void Pause() {
        pauseCanvas.SetActive(true);
    }

    public void Resume() {
        pauseCanvas.SetActive(false);
    }

    public void Disconnect() {
        PhotonNetwork.LeaveRoom();
        PhotonNetwork.LoadLevel("Lobby");
    }

    // public void OnPlayerDisconnected(Player player) {
    //     GameObject newFeed = Instantiate(playerFeed, new Vector2(0, 0), Quaternion.identity);
    //     newFeed.transform.SetParent(feedHolder.transform, false);
    //     newFeed.GetComponent<TextMeshProUGUI>().text = "-" + player.NickName + " left the game";
    //     newFeed.GetComponent<TextMeshProUGUI>().color = Color.red;
    // }

    // public void OnPlayerConnected(Player player) {
    //     GameObject newFeed = Instantiate(playerFeed, new Vector2(0, 0), Quaternion.identity);
    //     newFeed.transform.SetParent(feedHolder.transform, false);
    //     newFeed.GetComponent<TextMeshProUGUI>().text = "-" + player.NickName + " joined the game";
    //     newFeed.GetComponent<TextMeshProUGUI>().color = Color.green;
    // }
}
