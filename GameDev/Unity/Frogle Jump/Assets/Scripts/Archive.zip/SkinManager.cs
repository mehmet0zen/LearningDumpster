using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;

public class SkinManager : MonoBehaviour
{

    //For Player
    [Header("Player")]
    public SpriteRenderer currentSkin;
    public Animator playerAnimator;
    public List<Sprite> frogSkins = new List<Sprite>();
    public List<RuntimeAnimatorController> frogAnimators = new List<RuntimeAnimatorController>();
    public GameObject player;
    public GameObject mainCamera;

    //For UI
    [Header("UI")]
    public Sprite[] skinIcons;
    int skinNumber = 0;
    
    void OnMouseDown() {
        if (skinNumber == skinIcons.Length - 1) {
            skinNumber = 0;
        } else {
            skinNumber++;
        }
        gameObject.GetComponent<SpriteRenderer>().sprite = skinIcons[skinNumber];
        currentSkin.sprite = frogSkins[skinNumber];
        playerAnimator.runtimeAnimatorController = frogAnimators[skinNumber];
    }

    public void PlayGame() {
        DontDestroyOnLoad(player);
        DontDestroyOnLoad(mainCamera);
        player.GetComponent<PlayerController>().enabled = true;
        mainCamera.GetComponent<CameraFollow>().enabled = true;
    }
}
