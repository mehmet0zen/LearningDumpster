using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraControlMultiplayer : MonoBehaviour
{
    GameObject target;
    Vector3 newPosition;
    float followX;

    public void SetTarget(Transform Playertarget) {
        target = Playertarget.gameObject;
    }
    private void Update()
    {
        // // if (target.position.y > transform.position.y) 
        // // {
        //     newPosition = new Vector3(target.position.x, target.position.y, transform.position.z);
        // // }
        // transform.position = newPosition;
        
        transform.position = target.transform.position;
    }
}
