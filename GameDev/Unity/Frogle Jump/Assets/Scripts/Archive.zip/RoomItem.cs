using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using Photon.Pun;
public class RoomItem : MonoBehaviour
{
    public TextMeshProUGUI roomName;
    public LobbyManager manager;
    public string roomPassword;
    public GameObject roomPrivateIcon;
    public GameObject roomPublicIcon;

    private void Start() {
        manager = FindObjectOfType<LobbyManager>();
    }

    public void SetRoomDetails(string _roomname, string _roompass) {
        roomName.text = _roomname;
        roomPassword = _roompass;
    }

    private void Update() {
        roomPrivateIcon.SetActive(manager.roomLocked);
        roomPublicIcon.SetActive(!manager.roomLocked);
    }

    public void OnClickItem() {
        if (!manager.roomLocked) {
            manager.lobbyPanel.SetActive(false);
            manager.passwordPanel.SetActive(true);
        } else {
            manager.JoinRoom(roomName.text);
        }
    }
    
}
