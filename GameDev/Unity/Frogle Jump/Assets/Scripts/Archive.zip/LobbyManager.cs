using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.UI;
using Photon.Pun;
using Photon.Realtime;
using TMPro;

public class LobbyManager : MonoBehaviourPunCallbacks
{
    public TMP_InputField roomInput;
    public GameObject lobbyPanel;
    public GameObject roomPanel;
    public GameObject createRoomPanel;
    public GameObject passwordPanel;
    public TextMeshProUGUI roomName;
    public TMP_InputField CreatorRoomPasscode;
    public TMP_InputField JoinerRoomPasscode;
    public TMP_InputField renameInput;

    public RoomItem roomItemPrefab;
    public List<RoomItem> roomItems = new List<RoomItem>();
    public Transform contentObjectForRoom;

    public TextMeshProUGUI errorMessage;

    public List<PlayerItem> playerItems = new List<PlayerItem>();
    public PlayerItem playerItemPrefab;
    public Transform contentObjectForPlayer;
    public GameObject playButton;

    public float timeBetweenUpdates = 1.5f;
    public bool roomLocked = false;
    float nextUpdateTime;
    bool roomExists;
    string roomPassword;
    TextMeshProUGUI usernamePlaceholder;
    
    void Start()
    {
        PhotonNetwork.JoinLobby();
        renameInput.placeholder.GetComponent<TextMeshProUGUI>().text = PhotonNetwork.NickName;
    }
    void Update() {
        if (PhotonNetwork.IsMasterClient) {
            if (PhotonNetwork.CurrentRoom.PlayerCount >= 2) {
                playButton.GetComponentInChildren<TextMeshProUGUI>().text = "Play!";
                playButton.GetComponentInChildren<TextMeshProUGUI>().color = Color.green;
                playButton.GetComponent<Button>().enabled = true;
            } else {
                playButton.GetComponentInChildren<TextMeshProUGUI>().text = "min 2 \n\nrequired!";
                playButton.GetComponentInChildren<TextMeshProUGUI>().color = Color.white;
                playButton.GetComponent<Button>().enabled = false;
            }
        } else {
            playButton.GetComponentInChildren<TextMeshProUGUI>().text = "wait for \n\nadmin";
            playButton.GetComponentInChildren<TextMeshProUGUI>().color = Color.white;
        }

        if (renameInput.text.Length >= 3) {
            PlayerPrefs.SetString("userName", renameInput.text);
            PhotonNetwork.NickName = PlayerPrefs.GetString("userName");
            renameInput.placeholder.GetComponent<TextMeshProUGUI>().text = PhotonNetwork.NickName;
        }
    }


    void UpdateRoomList(List<RoomInfo> list) {
        foreach(RoomItem item in roomItems) {
            Destroy(item.gameObject);
        }
        roomItems.Clear();

        foreach(RoomInfo room in list) {
            RoomItem newRoom = Instantiate(roomItemPrefab, contentObjectForRoom);
            newRoom.SetRoomDetails(room.Name, roomPassword);
            roomLocked = newRoom.roomPassword.Length >= 1;
            roomItems.Add(newRoom);
        }
    }
    public override void OnRoomListUpdate(List<RoomInfo> roomList)
    {
        if (Time.time >= nextUpdateTime) {
            UpdateRoomList(roomList);   
            nextUpdateTime = Time.time + timeBetweenUpdates;
        }
    }

    void UpdatePlayerList() {
        foreach (PlayerItem item in playerItems) {
            Destroy(item.gameObject);
        }
        playerItems.Clear();

        if (PhotonNetwork.CurrentRoom == null) {
            return;
        }

        foreach(KeyValuePair<int, Player> player in PhotonNetwork.CurrentRoom.Players) {
            PlayerItem newPlayer = Instantiate(playerItemPrefab, contentObjectForPlayer);
            newPlayer.SetPlayerInfo(player.Value);

            if (player.Value == PhotonNetwork.LocalPlayer) {
                newPlayer.ApplyLocalChanges();
            }

            playerItems.Add(newPlayer);
        }
    }

    public override void OnPlayerEnteredRoom(Player newPlayer)
    {
        UpdatePlayerList();
    }

    public override void OnPlayerLeftRoom(Player otherPlayer)
    {
        UpdatePlayerList();
    }

    public void OnClickCreate() {
        if (roomInput.text.Length > 0) {
            roomPassword = CreatorRoomPasscode.text;
            PhotonNetwork.CreateRoom(roomInput.text, new RoomOptions() { MaxPlayers = 4, BroadcastPropsChangeToAll = true });
        } else {
            errorMessage.text = "Room Name is Required!";
        }
    }

    public void CreateRoomPanel() {
        lobbyPanel.SetActive(false);
        roomPanel.SetActive(false);
        createRoomPanel.SetActive(true);
    }

    public void Disconnect() {
        PhotonNetwork.Disconnect();
    }

    public void OnClickPlayButton() {
        if (PhotonNetwork.IsMasterClient) {
            PhotonNetwork.LoadLevel("MultiplayerGame");
        }
    }
    public void OnPasswordEntered() {
        if (JoinerRoomPasscode.text == roomPassword) {
            JoinRoom(roomName.text);
        } else {
            passwordPanel.SetActive(false);
            lobbyPanel.SetActive(true);
            errorMessage.text = "Incorrect Password!";
        }
        JoinerRoomPasscode.text = "";
    }

    public void JoinRoom(string roomName) {
        PhotonNetwork.JoinRoom(roomName);
    }
    public void LeaveRoom() {
        PhotonNetwork.LeaveRoom();
        roomInput.text = "";
        CreatorRoomPasscode.text = "";
        JoinerRoomPasscode.text = "";
    }


    public override void OnLeftRoom()
    {
        roomPanel.SetActive(false);
        createRoomPanel.SetActive(false);
        lobbyPanel.SetActive(true);
    }

    public override void OnConnectedToMaster()
    {
        PhotonNetwork.JoinLobby();
    }
    public override void OnJoinedRoom()
    {
        lobbyPanel.SetActive(false);
        createRoomPanel.SetActive(false);
        passwordPanel.SetActive(false);
        roomPanel.SetActive(true);
        roomName.text = PhotonNetwork.CurrentRoom.Name;
        UpdatePlayerList();
    }

    public override void OnJoinRoomFailed(short returnCode, string message)
    {
        PhotonNetwork.LoadLevel("Lobby");
        errorMessage.text = message;
        errorMessage.color = Color.red;
    }
}
