using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using Photon.Pun;
using TMPro;

public class ConnectToServer : MonoBehaviourPunCallbacks
{
    public TMP_InputField userNameInput;
    public TextMeshProUGUI buttonText;
    public TextMeshProUGUI errorMessage;

    private void Awake() {
        if (PlayerPrefs.GetString("userName", "") != "") {
            PhotonNetwork.NickName = PlayerPrefs.GetString("userName");
            buttonText.text = "Connecting...";
            PhotonNetwork.AutomaticallySyncScene = true;
            PhotonNetwork.ConnectUsingSettings();
            SceneManager.LoadScene("StartMenu");
        }
    }
    public void OnClickConnect() {
        if (userNameInput.text.Length > 0) {
            PhotonNetwork.NickName = userNameInput.text;
            PlayerPrefs.SetString("userName", userNameInput.text);
            buttonText.text = "Connecting...";
            errorMessage.text = " ";
            PhotonNetwork.AutomaticallySyncScene = true;
            PhotonNetwork.ConnectUsingSettings();
        } else {
            errorMessage.text = "Enter a \n\nNickname!\n\n";
            userNameInput.placeholder.color = Color.red;
        }
    }

    public void Disconnect() {
        PhotonNetwork.Disconnect();
    }

    public override void OnConnectedToMaster() {
        SceneManager.LoadScene("StartMenu");
    }
}
